import os
import hashlib
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import requests
import urllib3
from dotenv import load_dotenv


# ============================================================
# CONFIGURATION
# ============================================================

load_dotenv()

OTX_API_KEY = os.getenv("OTX_API_KEY", "").strip()
THREATFOX_AUTH_KEY = os.getenv("THREATFOX_AUTH_KEY", "").strip()
URLHAUS_AUTH_KEY = os.getenv("URLHAUS_AUTH_KEY", "").strip()
PHISHTANK_APP_KEY = os.getenv("PHISHTANK_APP_KEY", "").strip()

HEC_URL = os.getenv("SPLUNK_HEC_URL", "").strip()
HEC_TOKEN = os.getenv("SPLUNK_HEC_TOKEN", "").strip()
SPLUNK_INDEX = os.getenv("SPLUNK_INDEX", "darkweb_intel").strip()

# Set SPLUNK_VERIFY_TLS=true to verify using the system CA store.
# Or set SPLUNK_CA_CERT=/path/to/your/ca.pem to verify with a lab CA.
VERIFY_TLS = os.getenv("SPLUNK_VERIFY_TLS", "true").strip().lower() == "true"
CA_CERT = os.getenv("SPLUNK_CA_CERT", "").strip()
TLS_VERIFY = CA_CERT if CA_CERT else VERIFY_TLS

DB_PATH = os.getenv("STATE_DB", "state/dedupe.sqlite3")
LOG_FILE = os.getenv("LOG_FILE", "logs/collector.log")

TIMEOUT = int(os.getenv("HTTP_TIMEOUT", "30"))
OTX_MAX_PAGES = int(os.getenv("OTX_MAX_PAGES", "3"))
THREATFOX_DAYS = int(os.getenv("THREATFOX_DAYS", "3"))
URLHAUS_LIMIT = int(os.getenv("URLHAUS_LIMIT", "500"))

Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)
logger = logging.getLogger(__name__)

# urllib3 emits this warning when verify=False is used.
# This only suppresses the warning; it does NOT enable TLS verification.
if TLS_VERIFY is False:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    logger.warning(
        "TLS certificate verification is DISABLED for Splunk HEC. "
        "Use only in a controlled lab."
    )

session = requests.Session()
session.headers.update({
    "User-Agent": "Splunk-Threat-Intel-Lab/1.0"
})


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sent_iocs (
                dedupe_key TEXT PRIMARY KEY,
                threat_source TEXT,
                ioc TEXT,
                ioc_type TEXT,
                first_sent TEXT
            )
        """)
    logger.info("SQLite database initialized")


def generate_dedupe_key(record):
    raw_key = (
        f"{record['threat_source']}|"
        f"{record['ioc_type']}|"
        f"{record['ioc']}"
    )
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def ioc_already_sent(dedupe_key):
    with sqlite3.connect(DB_PATH) as conn:
        result = conn.execute(
            "SELECT 1 FROM sent_iocs WHERE dedupe_key = ?",
            (dedupe_key,)
        ).fetchone()
    return result is not None


def mark_ioc_sent(record, dedupe_key):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            INSERT OR IGNORE INTO sent_iocs
            (dedupe_key, threat_source, ioc, ioc_type, first_sent)
            VALUES (?, ?, ?, ?, ?)
        """, (
            dedupe_key,
            record["threat_source"],
            record["ioc"],
            record["ioc_type"],
            datetime.now(timezone.utc).isoformat()
        ))


# ============================================================
# IOC NORMALIZATION
# ============================================================

def normalize(source, value, ioc_type, raw=None):
    if value is None:
        return None

    value = str(value).strip()
    if not value:
        return None

    raw = raw or {}

    return {
        "event_type": "threat_intel_ioc",
        "threat_source": source,
        "ioc": value,
        "ioc_type": ioc_type or "unknown",
        "description": raw.get("description", ""),
        "malware": raw.get("malware", ""),
        "reference": raw.get("reference", ""),
        "first_seen": raw.get("first_seen", ""),
        "collected_at": datetime.now(timezone.utc).isoformat()
    }


# ============================================================
# SPLUNK HTTP EVENT COLLECTOR (HEC)
# ============================================================

def send_to_splunk(event, sourcetype="threatintel:json"):
    if not HEC_URL or not HEC_TOKEN:
        logger.error("Splunk HEC URL or token is missing")
        return False

    payload = {
        "index": SPLUNK_INDEX,
        "sourcetype": sourcetype,
        "event": event
    }

    try:
        response = session.post(
            HEC_URL,
            headers={
                "Authorization": f"Splunk {HEC_TOKEN}",
                "Content-Type": "application/json"
            },
            json=payload,
            timeout=TIMEOUT,
            verify=TLS_VERIFY
        )
        response.raise_for_status()

        try:
            result = response.json()
        except ValueError:
            logger.error("Splunk HEC returned a non-JSON response")
            return False

        if result.get("code") != 0:
            logger.error("Splunk HEC rejected event: %s", result)
            return False

        return True

    except requests.RequestException as exc:
        logger.error("Splunk HEC request failed: %s", exc)
        return False


# ============================================================
# PUBLISH IOC RECORDS
# ============================================================

def publish(records):
    sent = 0
    skipped = 0
    failed = 0

    for record in records:
        if not record:
            continue

        dedupe_key = generate_dedupe_key(record)

        if ioc_already_sent(dedupe_key):
            skipped += 1
            continue

        if send_to_splunk(record):
            # Mark only after HEC confirms successful ingestion.
            mark_ioc_sent(record, dedupe_key)
            sent += 1
        else:
            failed += 1

    logger.info(
        "Publish summary | sent=%d skipped=%d failed=%d",
        sent, skipped, failed
    )

    print(f"New events sent: {sent}")
    print(f"Duplicates skipped: {skipped}")
    print(f"Failed submissions: {failed}")

    return sent


# ============================================================
# ALIENVAULT OTX COLLECTOR
# ============================================================

def collect_otx():
    if not OTX_API_KEY:
        logger.warning("OTX skipped: API key missing")
        return []

    headers = {"X-OTX-API-KEY": OTX_API_KEY}
    url = "https://otx.alienvault.com/api/v1/pulses/subscribed"
    params = {"limit": 50, "page": 1}
    records = []

    for _ in range(OTX_MAX_PAGES):
        try:
            response = session.get(
                url,
                headers=headers,
                params=params,
                timeout=TIMEOUT
            )
            response.raise_for_status()
            data = response.json()

            for pulse in data.get("results", []):
                for indicator in pulse.get("indicators", []):
                    record = normalize(
                        "AlienVault OTX",
                        indicator.get("indicator"),
                        indicator.get("type"),
                        {
                            "description": (
                                indicator.get("description")
                                or pulse.get("name", "")
                            ),
                            "reference": indicator.get("id", ""),
                            "malware": pulse.get("name", "")
                        }
                    )
                    if record:
                        records.append(record)

            next_url = data.get("next")
            if not next_url:
                break

            url = next_url
            params = None

        except (requests.RequestException, ValueError) as exc:
            logger.error("OTX collection error: %s", exc)
            break

    logger.info("OTX collected %d indicators", len(records))
    return records


# ============================================================
# THREATFOX COLLECTOR
# ============================================================

def collect_threatfox():
    if not THREATFOX_AUTH_KEY:
        logger.warning("ThreatFox skipped: API key missing")
        return []

    headers = {"Auth-Key": THREATFOX_AUTH_KEY}
    body = {
        "query": "get_iocs",
        "days": THREATFOX_DAYS
    }
    records = []

    try:
        response = session.post(
            "https://threatfox-api.abuse.ch/api/v1/",
            headers=headers,
            json=body,
            timeout=TIMEOUT
        )
        response.raise_for_status()
        data = response.json()

        if data.get("query_status") not in (None, "ok"):
            logger.warning(
                "ThreatFox API returned status: %s",
                data.get("query_status")
            )
            return records

        for item in data.get("data") or []:
            record = normalize(
                "ThreatFox",
                item.get("ioc"),
                item.get("ioc_type"),
                {
                    "description": item.get("threat_type", ""),
                    "malware": item.get("malware_printable", ""),
                    "reference": item.get("reference", ""),
                    "first_seen": item.get("first_seen", "")
                }
            )
            if record:
                records.append(record)

    except (requests.RequestException, ValueError) as exc:
        logger.error("ThreatFox collection error: %s", exc)

    logger.info("ThreatFox collected %d indicators", len(records))
    return records


# ============================================================
# URLHAUS COLLECTOR
# ============================================================

def collect_urlhaus():
    headers = {}
    if URLHAUS_AUTH_KEY:
        headers["Auth-Key"] = URLHAUS_AUTH_KEY

    records = []

    try:
        response = session.get(
            "https://urlhaus-api.abuse.ch/v1/urls/recent/",
            headers=headers,
            timeout=TIMEOUT
        )
        response.raise_for_status()
        data = response.json()

        for item in data.get("urls", [])[:URLHAUS_LIMIT]:
            payloads = item.get("payloads") or []
            malware = (
                payloads[0].get("signature", "")
                if payloads else ""
            )

            record = normalize(
                "URLhaus",
                item.get("url"),
                "url",
                {
                    "description": item.get("threat", ""),
                    "malware": malware,
                    "reference": item.get("urlhaus_reference", ""),
                    "first_seen": item.get("date_added", "")
                }
            )
            if record:
                records.append(record)

    except (requests.RequestException, ValueError) as exc:
        logger.error("URLhaus collection error: %s", exc)

    logger.info("URLhaus collected %d indicators", len(records))
    return records


# ============================================================
# PHISHTANK COLLECTOR
# ============================================================

def collect_phishtank():
    url = "https://data.phishtank.com/data/online-valid.json"
    params = {}

    if PHISHTANK_APP_KEY:
        params["app_key"] = PHISHTANK_APP_KEY

    records = []

    try:
        response = session.get(
            url,
            params=params,
            timeout=TIMEOUT
        )
        response.raise_for_status()
        data = response.json()

        if not isinstance(data, list):
            logger.error("PhishTank returned an unexpected response")
            return records

        for item in data:
            if str(item.get("verified", "")).lower() != "yes":
                continue

            record = normalize(
                "PhishTank",
                item.get("url"),
                "url",
                {
                    "description": item.get("phish_detail_page", ""),
                    "reference": item.get("phish_id", ""),
                    "first_seen": item.get("submission_time", "")
                }
            )
            if record:
                records.append(record)

    except (requests.RequestException, ValueError) as exc:
        logger.error("PhishTank collection error: %s", exc)

    logger.info("PhishTank collected %d indicators", len(records))
    return records


# ============================================================
# MAIN EXECUTION
# ============================================================

def main():
    init_db()

    if not HEC_URL or not HEC_TOKEN:
        logger.error("Missing SPLUNK_HEC_URL or SPLUNK_HEC_TOKEN")
        print("ERROR: Configure Splunk HEC URL and token in .env")
        return

    logger.info("Dark Web Threat Intelligence Collection Started")

    all_records = []

    collectors = [
        collect_otx,
        collect_threatfox,
        collect_urlhaus,
        collect_phishtank
    ]

    for collector in collectors:
        try:
            records = collector()
            all_records.extend(records)
        except Exception:
            logger.exception(
                "Collector failed: %s",
                collector.__name__
            )

    sent = publish(all_records)

    print("------------------------------------")
    print("THREAT INTELLIGENCE COLLECTION")
    print("------------------------------------")
    print(f"Total collected: {len(all_records)}")
    print(f"New events sent to Splunk: {sent}")
    print("Collection completed.")
    print(f"Check logs: {LOG_FILE}")

    logger.info(
        "Collection completed. Total=%d Sent=%d",
        len(all_records),
        sent
    )


if __name__ == "__main__":
    main()