#!/usr/bin/env python3
"""Enrich existing IOC rows in the collector's SQLite sent_iocs table with VirusTotal.

Expected source schema (created by darkweb_splunk_collector/collector.py):
  sent_iocs(dedupe_key, threat_source, ioc, ioc_type, first_sent)

Only retrieves existing VirusTotal reports. It does not upload files or submit URLs.
"""

import base64
import ipaddress
import json
import logging
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit

import requests
from dotenv import load_dotenv

APP_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(APP_DIR, ".env"))

DB_PATH = os.getenv("STATE_DB", os.path.join(APP_DIR, "state", "dedupe.sqlite3"))
VT_API_KEY = os.getenv("VT_API_KEY", "").strip()
HEC_URL = os.getenv("SPLUNK_HEC_URL", "").strip()
HEC_TOKEN = os.getenv("SPLUNK_HEC_TOKEN", "").strip()
SPLUNK_INDEX = os.getenv("SPLUNK_INDEX", "darkweb_intel").strip()
VERIFY_TLS = os.getenv("SPLUNK_VERIFY_TLS", "true").lower() in ("1", "true", "yes", "on")
HTTP_TIMEOUT = int(os.getenv("HTTP_TIMEOUT", "30"))
MAX_PER_RUN = int(os.getenv("VT_MAX_PER_RUN", "4"))
DAILY_LIMIT = int(os.getenv("VT_DAILY_LIMIT", "450"))
MIN_INTERVAL = float(os.getenv("VT_MIN_INTERVAL_SECONDS", "16.5"))
LOG_FILE = os.getenv("VT_LOG_FILE", os.path.join(APP_DIR, "logs", "virustotal.log"))

os.makedirs(os.path.dirname(LOG_FILE) or ".", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("vt-enricher")

VT_BASE = "https://www.virustotal.com/api/v3"


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def connect_db():
    if not os.path.isfile(DB_PATH):
        raise FileNotFoundError(
            f"SQLite database not found: {DB_PATH}. Run collector.py first and check STATE_DB."
        )
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vt_cache (
            ioc_key TEXT PRIMARY KEY,
            ioc TEXT NOT NULL,
            ioc_type TEXT NOT NULL,
            status_code INTEGER,
            result_json TEXT,
            checked_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vt_usage (
            usage_date TEXT PRIMARY KEY,
            request_count INTEGER NOT NULL DEFAULT 0
        )
    """)
    conn.commit()
    return conn


def normalize_indicator(raw_ioc, raw_type):
    value = (raw_ioc or "").strip()
    typ = (raw_type or "").strip().lower()
    if not value:
        return None

    # Remove common descriptive type suffixes from feed adapters.
    typ = typ.replace(" ", "_").replace("-", "_")
    aliases = {
        "ip": "ip", "ipv4": "ip", "ipv6": "ip", "ip_address": "ip",
        "domain": "domain", "hostname": "domain", "host": "domain",
        "url": "url", "uri": "url",
        "md5": "file", "md5_hash": "file", "sha1": "file", "sha1_hash": "file",
        "sha256": "file", "sha256_hash": "file", "sha_256": "file",
        "sha_1": "file",
    }
    kind = aliases.get(typ)

    # Infer when the feed's type is unknown or non-standard.
    if not kind:
        if value.lower().startswith(("http://", "https://")):
            kind = "url"
        else:
            candidate = value
            # Handle common IPv4:port indicators, but do not split IPv6 literals.
            if candidate.count(":") == 1 and "." in candidate:
                host, port = candidate.rsplit(":", 1)
                if port.isdigit():
                    candidate = host
            try:
                ipaddress.ip_address(candidate.strip("[]"))
                value = candidate.strip("[]")
                kind = "ip"
            except ValueError:
                if len(value) in (32, 40, 64) and all(c in "0123456789abcdefABCDEF" for c in value):
                    kind = "file"
                elif "." in value and " " not in value:
                    kind = "domain"

    if kind == "ip":
        candidate = value
        if candidate.count(":") == 1 and "." in candidate:
            host, port = candidate.rsplit(":", 1)
            if port.isdigit():
                candidate = host
        try:
            value = str(ipaddress.ip_address(candidate.strip("[]")))
        except ValueError:
            return None
    elif kind == "domain":
        value = value.rstrip(".").lower()
        if "://" in value:
            value = urlsplit(value).hostname or ""
        if not value or "/" in value or " " in value:
            return None
    elif kind == "url":
        if not value.lower().startswith(("http://", "https://")):
            return None
    elif kind == "file":
        value = value.lower()
        if len(value) not in (32, 40, 64) or any(c not in "0123456789abcdef" for c in value):
            return None
    else:
        return None

    return kind, value


def vt_endpoint(kind, value):
    if kind == "ip":
        return f"{VT_BASE}/ip_addresses/{value}"
    if kind == "domain":
        return f"{VT_BASE}/domains/{value}"
    if kind == "url":
        encoded = base64.urlsafe_b64encode(value.encode()).decode().rstrip("=")
        return f"{VT_BASE}/urls/{encoded}"
    if kind == "file":
        return f"{VT_BASE}/files/{value}"
    raise ValueError("Unsupported IOC type")


def hec_send(session, event):
    payload = {"index": SPLUNK_INDEX, "sourcetype": "virustotal:json", "event": event}
    response = session.post(
        HEC_URL,
        headers={"Authorization": f"Splunk {HEC_TOKEN}"},
        json=payload,
        timeout=HTTP_TIMEOUT,
        verify=VERIFY_TLS,
    )
    response.raise_for_status()
    body = response.json()
    if body.get("code") != 0:
        raise RuntimeError(f"Splunk HEC rejected event: {body}")


def get_daily_usage(conn):
    day = datetime.now(timezone.utc).date().isoformat()
    row = conn.execute("SELECT request_count FROM vt_usage WHERE usage_date=?", (day,)).fetchone()
    return day, int(row[0]) if row else 0


def main():
    if not VT_API_KEY:
        raise RuntimeError("VT_API_KEY is missing from .env")
    if not HEC_URL or not HEC_TOKEN:
        raise RuntimeError("SPLUNK_HEC_URL or SPLUNK_HEC_TOKEN is missing from .env")

    conn = connect_db()
    columns = {r[1] for r in conn.execute("PRAGMA table_info(sent_iocs)")}
    required = {"ioc", "ioc_type", "dedupe_key", "threat_source"}
    if not required.issubset(columns):
        raise RuntimeError(
            "sent_iocs schema does not match the collector. Expected columns: " + ", ".join(sorted(required))
        )

    day, used = get_daily_usage(conn)
    remaining = max(0, DAILY_LIMIT - used)
    budget = min(MAX_PER_RUN, remaining)
    if budget <= 0:
        log.warning("Daily VirusTotal safety limit reached (%s/%s); exiting.", used, DAILY_LIMIT)
        return

    rows = conn.execute("""
        SELECT s.dedupe_key, s.threat_source, s.ioc, s.ioc_type
        FROM sent_iocs s
        LEFT JOIN vt_cache c ON c.ioc_key = lower(trim(s.ioc)) || '|' || lower(trim(s.ioc_type))
        WHERE c.ioc_key IS NULL
        ORDER BY s.first_sent ASC
        LIMIT ?
    """, (max(budget * 10, budget),)).fetchall()

    session = requests.Session()
    session.headers.update({"x-apikey": VT_API_KEY, "Accept": "application/json"})
    hec_session = requests.Session()
    processed = 0

    for row in rows:
        if processed >= budget:
            break
        normalized = normalize_indicator(row["ioc"], row["ioc_type"])
        if not normalized:
            continue
        kind, value = normalized
        cache_key = f"{row['ioc'].strip().lower()}|{row['ioc_type'].strip().lower()}"
        # Re-check the daily limit inside the loop.
        day, used = get_daily_usage(conn)
        if used >= DAILY_LIMIT:
            log.warning("Daily request cap reached.")
            break

        if processed:
            time.sleep(MIN_INTERVAL)

        status_code = None
        result = None
        try:
            resp = session.get(vt_endpoint(kind, value), timeout=HTTP_TIMEOUT)
            status_code = resp.status_code
            if status_code == 429:
                log.warning("VirusTotal rate limit response (429); stopping this run.")
                break
            if status_code == 404:
                result = {"status": "not_found"}
            else:
                resp.raise_for_status()
                body = resp.json()
                attrs = body.get("data", {}).get("attributes", {})
                stats = attrs.get("last_analysis_stats", {}) or {}
                result = {
                    "status": "found",
                    "malicious": int(stats.get("malicious", 0) or 0),
                    "suspicious": int(stats.get("suspicious", 0) or 0),
                    "harmless": int(stats.get("harmless", 0) or 0),
                    "undetected": int(stats.get("undetected", 0) or 0),
                    "reputation": attrs.get("reputation"),
                    "last_analysis_date": attrs.get("last_analysis_date"),
                    "tags": attrs.get("tags", []),
                }

            # Count actual API requests (including 404s), not skipped indicators.
            conn.execute("""
                INSERT INTO vt_usage(usage_date, request_count) VALUES (?, 1)
                ON CONFLICT(usage_date) DO UPDATE SET request_count=request_count+1
            """, (day,))

            event = {
                "event_type": "virustotal_enrichment",
                "threat_source": row["threat_source"],
                "ioc": row["ioc"],
                "ioc_type": row["ioc_type"],
                "vt_lookup_type": kind,
                "vt_status_code": status_code,
                "vt_status": result.get("status"),
                "malicious": result.get("malicious", 0),
                "suspicious": result.get("suspicious", 0),
                "harmless": result.get("harmless", 0),
                "undetected": result.get("undetected", 0),
                "reputation": result.get("reputation"),
                "last_analysis_date": result.get("last_analysis_date"),
                "tags": result.get("tags", []),
                "enriched_at": utc_now(),
            }
            hec_send(hec_session, event)
            conn.execute("""
                INSERT OR REPLACE INTO vt_cache(ioc_key, ioc, ioc_type, status_code, result_json, checked_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (cache_key, row["ioc"], row["ioc_type"], status_code, json.dumps(result), utc_now()))
            conn.commit()
            processed += 1
            log.info("Enriched %s (%s): status=%s malicious=%s", value, kind,
                     result.get("status"), result.get("malicious", 0))

        except requests.HTTPError as exc:
            log.error("HTTP error for %s: %s", row["ioc"], exc)
        except requests.RequestException as exc:
            log.error("Network error for %s: %s", row["ioc"], exc)
        except Exception as exc:
            log.exception("Failed processing %s: %s", row["ioc"], exc)

    log.info("Run complete. Enriched %d indicator(s).", processed)
    conn.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        log.error("Fatal: %s", error)
        sys.exit(1)
